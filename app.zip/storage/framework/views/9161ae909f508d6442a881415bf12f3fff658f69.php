<?php $__env->startSection('title', 'ลงประกาศ'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 50px;">
	<div class="worldadsth-addspace-form">
		<h3>ระบุรายละเอียดพื้นที่โฆษณาของคุณ</h3>
		<p>รายละเอียดที่ครอบคลุมและการอัพโหลดภาพที่คมชัด จะช่วยทำให้พื้นที่โฆษณาของคุณ <span style="color: #f39c12;">"ดูดี"</span> ขึ้นมากครับ</p>
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form role="form" method="POST" action="<?php echo e(url('/register')); ?>" class="form-horizontal">
					<?php echo e(csrf_field()); ?>


					<div class="panel panel-default">
			            <div class="panel-body">
			                <i class="fa fa-info-circle fa-2x" aria-hidden="true"></i>&nbsp; <span style="font-size: 16px;text-align: center;color: #000;">ข้อมูลเฉพาะของพื้นที่โฆษณา</span>
			                <hr>

							<div class="form-group">
							    <label for="title" class="col-sm-3 control-label">ชื่อโปรโมท<span style="color: red;"> *</span></label>
							    <div class="col-sm-9">
							      	<input type="text" class="form-control" id="title" placeholder="ป้ายว่างให้เช่า">
							    </div>
							</div>

							<div class="form-group">
							    <label for="type" class="col-sm-3 control-label">ประเภทพื้นที่โฆษณา<span style="color: red;"> *</span></label>
							    <div class="col-sm-9">
							      	<select class="form-control" id="type">
									  	<option>1</option>
									  	<option>2</option>
									  	<option>3</option>
									  	<option>4</option>
									  	<option>5</option>
									</select>
							    </div>
							</div>

							<div class="form-group">
							    <label for="size" class="col-sm-3 control-label">ขนาด<span style="color: red;"> *</span></label>
							    <div class="col-sm-9">
							      	<input type="text" class="form-control" id="size" placeholder="15 x 30 M">
							    </div>
							</div>

							<i class="fa fa-map-marker fa-2x" aria-hidden="true"></i>&nbsp; <span style="font-size: 16px;text-align: center;color: #000;">ตำแหน่งที่ตั้งของพื้นที่โฆษณา</span>
			                <hr>
			                <img src="/img/googlemap.jpg" style="width: 100%;height: auto;padding-bottom: 20px;">

			                <i class="fa fa-file-image-o fa-2x" aria-hidden="true"></i>&nbsp; <span style="font-size: 16px;text-align: center;color: #000;">รูปภาพประกอบ</span>
			                <hr>

			                <div class="row">
				                <div class="col-sm-12 col-md-3">
				                	<img src="/img/addspacebg.jpg" style="width: 100%;height: auto;">
				                </div>
				                <div class="col-sm-12 col-md-9">
				                	<input type="file" id="exampleInputFile" multiple>
				                	<p class="help-block">Example block-level help text here.</p>
				                </div>
				            </div>

				            <hr>

				            <div class="form-group">
		                        <center>
		                            <button type="submit" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp; ลงประกาศ</button>
		                        </center>
							</div>
			            </div>
			        </div>
				</form>
			</div>
		    <div class="col-sm-12 col-md-3">
		    	<h4>* Tips</h4>
		    	<ul>
		    		<li></li>
		    		<li></li>
		    		<li></li>
		    		<li></li>
		    	</ul>
		    	<hr style="border: 1px solid #777;">
                <h5>Sponsored</h5>
                <img src="/img/addspacebg.jpg" style="width: 200px;height: 200px;">
		    </div>
		</div>

	    <hr style="border: 1px solid #000;">

	    <footer>
	        <p>worldadsth.com all right reserved.</p>
	    </footer>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>