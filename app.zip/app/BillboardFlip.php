<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillboardFlip extends Model
{
    protected $table = 'billboardflips';
}
