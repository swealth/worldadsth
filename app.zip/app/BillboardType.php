<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillboardType extends Model
{
    protected $table = 'billboardtypes';
}
